CREATE DATABASE  IF NOT EXISTS `dblivraria` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dblivraria`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dblivraria
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autor`
--

DROP TABLE IF EXISTS `autor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `id_endereco` int NOT NULL,
  `genero_literario` varchar(30) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_autor_pk_endereco` (`id_endereco`),
  CONSTRAINT `fk_autor_pk_endereco` FOREIGN KEY (`id_endereco`) REFERENCES `endereco` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autor`
--

LOCK TABLES `autor` WRITE;
/*!40000 ALTER TABLE `autor` DISABLE KEYS */;
INSERT INTO `autor` VALUES (1,'Jô Soares','54212454','jo@terra.com.br','115656585',1,'Ficção','https://s2-g1.glbimg.com/djhk98pQ-91eejd3bAHo9kQoGtY=/0x0:3872x2581/924x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2022/o/R/r6zQqcSXq5pawEuauWXA/age20220805001.jpg'),(2,'J. K. Rowling','54575454','rowling@england','545754545',1,'Ficção','https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/aaee/live/49328a80-f06b-11ee-a0c8-41149500b806.jpg.webp'),(3,'William Young','454512121','willian@gmail.com','444547',1,'Romance','https://cinebuzz.com.br/media/_versions/a_cabana_autor_widelg.jpg');
/*!40000 ALTER TABLE `autor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `id_endereco` int NOT NULL,
  `aniversario` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_cliente_pk_endereco` (`id_endereco`),
  CONSTRAINT `fk_cliente_pk_endereco` FOREIGN KEY (`id_endereco`) REFERENCES `endereco` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Márica Garcia','333','marcia.garcia@gmail.com','11-6669666',1,'1986-11-20'),(2,'Monica Dias','45154','monica@gmail.com','1155454',3,'1989-12-11'),(4,'Roberto Nascimento','45154745','roberto@gmail.com','1155787544',5,'1989-12-11'),(5,'Vanessa Oliveira','4578785','van.oliveira@gmail.com','1155784',6,'2004-12-11');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `endereco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_logradouro` enum('Rua','Alameda','Viela','Avenida','Travessa','Praça','Beco') DEFAULT NULL,
  `logradouro` varchar(100) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco`
--

LOCK TABLES `endereco` WRITE;
/*!40000 ALTER TABLE `endereco` DISABLE KEYS */;
INSERT INTO `endereco` VALUES (1,'Rua','Felipe Martins','80','Apto 22','03542000','Jardim Novo'),(2,'Rua','Padre Miguel','110',NULL,'23515100','Vila Alpina'),(3,'Rua','Pedro Novaes','78','Apt22','457454','Vila Esperança'),(4,'Rua','Pedro Novaes','78','Apt22','457454','Vila Esperança'),(5,'Rua','Pedro Novaes','78','Apt22','457454','Vila Esperança'),(6,'Avenida','Julia Moares','10','Apt12','487878','Jardim Alegre'),(7,'Rua','Moares Moreira','100','Casa dos fundos','012478','Bragança');
/*!40000 ALTER TABLE `endereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `id_endereco` int NOT NULL,
  `cargo` varchar(50) NOT NULL,
  `salario` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,'Jair Pedro','445','jair@gmail.com','1166656565',2,'Vendedor',3000.00),(2,'Tadeu Melo','457878','ta.melo@gmail.com','145484',7,'Gerente',4000.00);
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itensvenda`
--

DROP TABLE IF EXISTS `itensvenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itensvenda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_venda` int NOT NULL,
  `id_produto` int NOT NULL,
  `quantidade` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_itensvenda_pk_venda` (`id_venda`),
  KEY `fk_itensvenda_pk_produto` (`id_produto`),
  CONSTRAINT `fk_itensvenda_pk_produto` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id`),
  CONSTRAINT `fk_itensvenda_pk_venda` FOREIGN KEY (`id_venda`) REFERENCES `venda` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itensvenda`
--

LOCK TABLES `itensvenda` WRITE;
/*!40000 ALTER TABLE `itensvenda` DISABLE KEYS */;
INSERT INTO `itensvenda` VALUES (1,1,1,2),(2,1,3,1),(3,3,4,2);
/*!40000 ALTER TABLE `itensvenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagamento`
--

DROP TABLE IF EXISTS `pagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagamento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_venda` int NOT NULL,
  `total_pagar` decimal(7,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pagamento_pk_venda` (`id_venda`),
  CONSTRAINT `fk_pagamento_pk_venda` FOREIGN KEY (`id_venda`) REFERENCES `venda` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagamento`
--

LOCK TABLES `pagamento` WRITE;
/*!40000 ALTER TABLE `pagamento` DISABLE KEYS */;
INSERT INTO `pagamento` VALUES (1,1,177.93),(2,3,500.00);
/*!40000 ALTER TABLE `pagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `preco` decimal(6,2) NOT NULL,
  `foto1` varchar(255) DEFAULT NULL,
  `foto2` varchar(255) DEFAULT NULL,
  `foto3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Livro Harry Porter - Pedra Filosofal','Livro de Fantasia',44.00,'https://m.media-amazon.com/images/I/81ibfYk4qmL._SL1500_.jpg','https://m.media-amazon.com/images/I/71gRzyfte2L._SL1500_.jpg','https://m.media-amazon.com/images/I/71gRzyfte2L._SL1500_.jpg'),(2,'A Cabana','Livro de Romance',25.99,'https://m.media-amazon.com/images/I/91fLBlcmpXL._SL1500_.jpg','https://m.media-amazon.com/images/I/A1WLPpdlRiL._SL1500_.jpg','https://m.media-amazon.com/images/I/A1WLPpdlRiL._SL1500_.jpg'),(3,'Star Wars - A vingança dos Sith','Livro de Ficção',89.93,'https://m.media-amazon.com/images/I/818+puUkxmL._SL1500_.jpg','https://m.media-amazon.com/images/I/71GX8kJPn-L._SL1181_.jpg','https://m.media-amazon.com/images/I/51l3G-pQatL._SL1181_.jpg'),(4,'O Xângo de BeckerStreet ','Livro de Romance',49.98,'https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg','https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg','https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg'),(5,'Meu Pé de Laranja Lima','Livro infanto juvenil',25.50,'https://m.media-amazon.com/images/I/914xinLX3HL._SL1500_.jpg','https://m.media-amazon.com/images/I/61XUSS+hCEL.jpg','https://m.media-amazon.com/images/I/61-0g3ZN+vL.jpg'),(6,'Meu Pé de Laranja Lima','Livro infanto juvenil',25.50,'https://m.media-amazon.com/images/I/914xinLX3HL._SL1500_.jpg','https://m.media-amazon.com/images/I/61XUSS+hCEL.jpg','https://m.media-amazon.com/images/I/61-0g3ZN+vL.jpg'),(7,'O Xângo de BeckerStreet ','Livro de Romance',49.98,'https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg','https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg','https://m.media-amazon.com/images/I/71jEyoyqOpL._SL1500_.jpg'),(8,'Ayrton Senna','Livro de Esporte Uma Lenda a Toda Velocidade: Uma Jornada Interativa',215.94,'https://m.media-amazon.com/images/I/71b-XOvFhuL._SL1297_.jpg','https://m.media-amazon.com/images/I/91mDuS4q50L._SL1500_.jpg','https://m.media-amazon.com/images/I/71Dpe-Q0NYL._SL1500_.jpg'),(9,'Nunca deixe de tentar','Livro de Esporte Este é o primeiro título da coleção Na Vida Como no Esporte, que revela os princípios nos quais grandes atletas e treinadores pautaram suas trajetórias e mostra como esses valores transcendem o universo esportivo e podem ser aplicados à vida pessoal e profissional.',31.92,'https://m.media-amazon.com/images/I/81-UQCHAM2L._SL1500_.jpg','https://m.media-amazon.com/images/I/91hvT1nmFpL._SL1500_.jpg','https://m.media-amazon.com/images/I/91hvT1nmFpL._SL1500_.jpg'),(10,'Curso Básico de Desenho','Livro de Mangá',21.65,'https://m.media-amazon.com/images/I/71rqmr8gJoL._SL1360_.jpg','https://m.media-amazon.com/images/I/71uAwT9delL._SL1360_.jpg','https://m.media-amazon.com/images/I/71uAwT9delL._SL1360_.jpg');
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venda`
--

DROP TABLE IF EXISTS `venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_funcionario` int NOT NULL,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_venda_pk_cliente` (`id_cliente`),
  KEY `fk_venda_pk_funcionario` (`id_funcionario`),
  CONSTRAINT `fk_venda_pk_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  CONSTRAINT `fk_venda_pk_funcionario` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venda`
--

LOCK TABLES `venda` WRITE;
/*!40000 ALTER TABLE `venda` DISABLE KEYS */;
INSERT INTO `venda` VALUES (1,1,1,'2025-05-08 18:28:54'),(2,1,1,'2025-05-15 20:10:52'),(3,4,2,'2025-05-15 20:12:04');
/*!40000 ALTER TABLE `venda` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-13 14:07:21
