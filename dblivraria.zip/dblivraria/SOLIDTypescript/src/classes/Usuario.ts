export default class Usuario{
    id!:number;
    nomeusuario!:string;
    senha!:string;
    fotousuario!:string;
    criadoem!:Date;
    atualizadoem!:Date;

}