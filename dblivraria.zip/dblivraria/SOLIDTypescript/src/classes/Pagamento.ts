import Venda from "./Venda";

export default class Pagamento{
    id!:number;
    venda!:Venda;
    total_pagar!:number
}