import Pessoa from "./Pessoa";

export default class Autor extends Pessoa{
    genero_literario!:string;
}