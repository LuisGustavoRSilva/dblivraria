create database dblivraria;
use dblivraria;

create table produto(
id int auto_increment primary key,
nome varchar(100) not null,
descricao text not null,
preco decimal(6,2) not null
);

create table endereco(
id int auto_increment primary key,
tipo_logradouro enum("Rua","Alameda","Viela","Avenida","Travessa","Praça","Beco"),
logradouro varchar(100) not null,
numero varchar(10) not null,
complemento varchar(100),
cep varchar(10),
bairro varchar(50)
);

create table cliente(
id int auto_increment primary key,
nome varchar(100) not null,
cpf varchar(15) not null unique,
email varchar(100) not null unique,
telefone varchar(20),
id_endereco int not null,
aniversario date not null
);


create table autor(
id int auto_increment primary key,
nome varchar(100) not null,
cpf varchar(15) not null unique,
email varchar(100) not null unique,
telefone varchar(20),
id_endereco int not null,
genero_literario varchar(30)
);



create table funcionario(
id int auto_increment primary key,
nome varchar(100) not null,
cpf varchar(15) not null unique,
email varchar(100) not null unique,
telefone varchar(20),
id_endereco int not null,
cargo varchar(50) not null,
salario decimal(7,2)
);

create table venda(
id int auto_increment primary key,
id_cliente int not null,
id_funcionario int not null,
data_hora datetime default current_timestamp()
);

create table itensvenda(
id int auto_increment primary key,
id_venda int not null,
id_produto int not null,
quantidade int not null
);

create table pagamento(
id int auto_increment primary key,
id_venda int not null,
total_pagar decimal(7,2) not null
);

-- Criar os relacionamentos
ALTER TABLE cliente
ADD constraint `fk_cliente_pk_endereco`
FOREIGN KEY cliente(`id_endereco`)
REFERENCES endereco(`id`);

ALTER TABLE autor
ADD constraint `fk_autor_pk_endereco`
FOREIGN KEY autor(`id_endereco`)
REFERENCES endereco(`id`);

ALTER TABLE funcionario
ADD constraint `fk_funcionario_pk_endereco`
FOREIGN KEY funcionario(`id_endereco`)
REFERENCES endereco(`id`);

ALTER TABLE venda
ADD constraint `fk_venda_pk_cliente`
FOREIGN KEY venda(`id_cliente`)
REFERENCES cliente(`id`);


ALTER TABLE venda
ADD constraint `fk_venda_pk_funcionario`
FOREIGN KEY venda(`id_funcionario`)
REFERENCES funcionario(`id`);

ALTER TABLE itensvenda
ADD constraint `fk_itensvenda_pk_venda`
FOREIGN KEY itensvenda(`id_venda`)
REFERENCES venda(`id`);



ALTER TABLE itensvenda
ADD constraint `fk_itensvenda_pk_produto`
FOREIGN KEY itensvenda(`id_produto`)
REFERENCES produto(`id`);

ALTER TABLE pagamento
ADD constraint `fk_pagamento_pk_venda`
FOREIGN KEY pagamento(`id_venda`)
REFERENCES venda(`id`);




